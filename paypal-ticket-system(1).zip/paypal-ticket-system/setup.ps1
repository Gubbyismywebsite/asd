#Requires -Version 5.1
<#
.SYNOPSIS
  Interactive setup wizard for the PayPal Ticket System's .env file.

.DESCRIPTION
  Tells you what to go grab (PayPal credentials, webhook ID), prompts you
  for it and for your chosen admin login, generates a session secret and
  a bcrypt hash of your admin password, and writes it all into .env.

  Safe to re-run: it reads whatever .env already exists first, so existing
  values become the defaults and pressing Enter keeps them unchanged.

.PARAMETER ProjectPath
  Folder containing package.json / .env.example. Defaults to the folder
  this script itself is sitting in.

.EXAMPLE
  .\setup.ps1
#>

[CmdletBinding()]
param(
    [string]$ProjectPath
)

$ErrorActionPreference = 'Stop'

if (-not $ProjectPath) {
    $ProjectPath = $PSScriptRoot
}
if (-not $ProjectPath) {
    $ProjectPath = (Get-Location).Path
}

$EnvPath        = Join-Path $ProjectPath '.env'
$HashScriptPath = Join-Path $ProjectPath 'scripts\hash-password.js'

function Write-Banner {
    param([string]$Text)
    Write-Host ""
    Write-Host ('=' * 70) -ForegroundColor DarkGray
    Write-Host $Text -ForegroundColor Cyan
    Write-Host ('=' * 70) -ForegroundColor DarkGray
}

function Get-Default {
    param($Value, $Fallback)
    if ($Value) { return $Value }
    return $Fallback
}

function Read-WithDefault {
    param([string]$Prompt, [string]$Default)
    $suffix = if ($Default) { " [$Default]" } else { '' }
    $value = Read-Host "$Prompt$suffix"
    if ([string]::IsNullOrWhiteSpace($value)) { return $Default }
    return $value
}

# Returns $null if the person just pressed Enter (meaning "keep whatever's
# already in .env"), otherwise the plaintext they typed.
function Read-SecretOrKeep {
    param([string]$Prompt, [bool]$HasExisting)
    $suffix = if ($HasExisting) { ' [press Enter to keep current]' } else { '' }
    $secure = Read-Host "$Prompt$suffix" -AsSecureString
    if ($secure.Length -eq 0) { return $null }
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try {
        return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    } finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

function New-RandomHex {
    param([int]$Bytes = 48)
    $buffer = New-Object byte[] $Bytes
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $rng.GetBytes($buffer)
    } finally {
        $rng.Dispose()
    }
    -join ($buffer | ForEach-Object { $_.ToString('x2') })
}

function Get-MaskedPreview {
    param([string]$Value)
    if ([string]::IsNullOrEmpty($Value)) { return '(not set)' }
    if ($Value.Length -le 4) { return '****' }
    return $Value.Substring(0, 2) + ('*' * ($Value.Length - 4)) + $Value.Substring($Value.Length - 2)
}

# ---------------------------------------------------------------------
# 0. Load whatever .env already exists, so re-running this script doesn't
#    make you retype everything.
# ---------------------------------------------------------------------
$existing = @{}
if (Test-Path $EnvPath) {
    Get-Content $EnvPath | ForEach-Object {
        if ($_ -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$') {
            $existing[$matches[1]] = $matches[2]
        }
    }
}

Write-Banner 'PayPal Ticket System - .env setup wizard'

Write-Host @'
This writes (or updates) the .env file the project reads its secrets from.
Before continuing, go grab these three things:

  1) PayPal Client ID + Secret
     https://developer.paypal.com/dashboard/
     -> Apps & Credentials -> Sandbox (or Live) tab -> your app
        (or "Create App" if you don't have one yet)

  2) PayPal Webhook ID
     Same app -> Webhooks -> Add Webhook
       URL:    https://<your-domain-or-ngrok-url>/webhook/paypal
       Events: PAYMENT.CAPTURE.COMPLETED
     -> open the webhook after saving it and copy its Webhook ID

  3) A username and password of YOUR OWN choosing for the admin dashboard
     (this is not a PayPal value - you make this one up)

Press Enter at any prompt to keep the current .env value shown in [brackets],
or to accept the suggested default if there isn't one yet.
'@ -ForegroundColor Yellow

$nodeAvailable = [bool](Get-Command node -ErrorAction SilentlyContinue)
if (-not $nodeAvailable) {
    Write-Host ''
    Write-Host "WARNING: 'node' was not found on PATH." -ForegroundColor Red
    Write-Host 'Node.js 18+ is required to run this project at all, and this' -ForegroundColor Red
    Write-Host 'script needs it to hash your admin password. Install it from' -ForegroundColor Red
    Write-Host 'https://nodejs.org, then re-run this script.' -ForegroundColor Red
}

# ---------------------------------------------------------------------
# 1. PayPal mode
# ---------------------------------------------------------------------
Write-Banner 'PayPal mode'
$currentMode = Get-Default $existing['PAYPAL_MODE'] 'sandbox'
do {
    $mode = Read-WithDefault "Type 'sandbox' or 'live'" $currentMode
} while ($mode -ne 'sandbox' -and $mode -ne 'live')

# ---------------------------------------------------------------------
# 2. PayPal credentials
# ---------------------------------------------------------------------
Write-Banner "PayPal credentials ($mode)"
$clientId = Read-WithDefault 'PAYPAL_CLIENT_ID' $existing['PAYPAL_CLIENT_ID']

$secretInput = Read-SecretOrKeep 'PAYPAL_CLIENT_SECRET' ([bool]$existing['PAYPAL_CLIENT_SECRET'])
$clientSecret = if ($secretInput) { $secretInput } else { $existing['PAYPAL_CLIENT_SECRET'] }

$webhookId = Read-WithDefault 'PAYPAL_WEBHOOK_ID' $existing['PAYPAL_WEBHOOK_ID']

# ---------------------------------------------------------------------
# 3. Server basics
# ---------------------------------------------------------------------
Write-Banner 'Server basics'
$brandName = Read-WithDefault 'Business/brand name shown at checkout' (Get-Default $existing['BRAND_NAME'] 'Your Company Name')
$port      = Read-WithDefault 'Port to run on' (Get-Default $existing['PORT'] '3000')
$baseUrl   = Read-WithDefault 'Base URL' (Get-Default $existing['BASE_URL'] "http://localhost:$port")
$nodeEnv   = Read-WithDefault 'NODE_ENV (production or development)' (Get-Default $existing['NODE_ENV'] 'production')
$dbPath    = Read-WithDefault 'DATABASE_PATH' (Get-Default $existing['DATABASE_PATH'] './data/tickets.db')

# ---------------------------------------------------------------------
# 4. Admin login
# ---------------------------------------------------------------------
Write-Banner 'Admin dashboard login'
$adminUser = Read-WithDefault 'ADMIN_USERNAME' (Get-Default $existing['ADMIN_USERNAME'] 'admin')

$adminPasswordHash = $existing['ADMIN_PASSWORD_HASH']
if ($nodeAvailable) {
    $plainPassword = Read-SecretOrKeep 'ADMIN_PASSWORD (plaintext - only the hash is ever saved)' ([bool]$adminPasswordHash)
    if ($plainPassword) {
        if (-not (Test-Path $HashScriptPath)) {
            Write-Host "Could not find $HashScriptPath - skipping password hashing." -ForegroundColor Red
        } else {
            $env:ADMIN_PASSWORD_PLAIN = $plainPassword
            try {
                $hashOutput = & node $HashScriptPath 2>&1
            } finally {
                Remove-Item Env:\ADMIN_PASSWORD_PLAIN -ErrorAction SilentlyContinue
            }
            $plainPassword = $null
            $match = $hashOutput | Select-String -Pattern 'ADMIN_PASSWORD_HASH=(.+)$'
            if ($match) {
                $adminPasswordHash = $match.Matches[0].Groups[1].Value.Trim()
                Write-Host 'Password hashed OK.' -ForegroundColor Green
            } else {
                Write-Host 'Could not read a hash back from scripts/hash-password.js:' -ForegroundColor Red
                Write-Host ($hashOutput -join "`n")
            }
        }
    }
} else {
    Write-Host "Skipping admin password (Node.js not found). Run this later:" -ForegroundColor Yellow
    Write-Host '  npm run hash-password -- "yourpassword"' -ForegroundColor Yellow
}

if (-not $adminPasswordHash) {
    $adminPasswordHash = 'replace_with_generated_bcrypt_hash'
    Write-Host ''
    Write-Host "No admin password was set - admin login won't work until you run:" -ForegroundColor Yellow
    Write-Host '  npm run hash-password -- "yourpassword"' -ForegroundColor Yellow
    Write-Host 'and paste the result into .env, or just re-run this script.' -ForegroundColor Yellow
}

# ---------------------------------------------------------------------
# 5. Session secret - generated automatically, never asked for
# ---------------------------------------------------------------------
$sessionSecret = $existing['SESSION_SECRET']
if (-not $sessionSecret -or $sessionSecret -eq 'replace_with_a_long_random_string') {
    $sessionSecret = New-RandomHex 48
    Write-Host ''
    Write-Host 'Generated a new SESSION_SECRET for you.' -ForegroundColor Green
}

# ---------------------------------------------------------------------
# 6. Write the .env file (backing up any existing one first)
# ---------------------------------------------------------------------
$lines = @(
    "# Written by setup.ps1 on $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    ''
    "PORT=$port"
    "NODE_ENV=$nodeEnv"
    "BASE_URL=$baseUrl"
    "BRAND_NAME=$brandName"
    ''
    "PAYPAL_MODE=$mode"
    "PAYPAL_CLIENT_ID=$clientId"
    "PAYPAL_CLIENT_SECRET=$clientSecret"
    "PAYPAL_WEBHOOK_ID=$webhookId"
    ''
    "ADMIN_USERNAME=$adminUser"
    "ADMIN_PASSWORD_HASH=$adminPasswordHash"
    "SESSION_SECRET=$sessionSecret"
    ''
    "DATABASE_PATH=$dbPath"
)

if (Test-Path $EnvPath) {
    $backupPath = "$EnvPath.bak.$(Get-Date -Format 'yyyyMMddHHmmss')"
    Copy-Item $EnvPath $backupPath
    Write-Host ''
    Write-Host "Backed up existing .env to $(Split-Path $backupPath -Leaf)" -ForegroundColor DarkGray
}

Set-Content -Path $EnvPath -Value $lines -Encoding UTF8

# ---------------------------------------------------------------------
# 7. Summary
# ---------------------------------------------------------------------
Write-Banner 'Done'
Write-Host "Wrote $EnvPath with:" -ForegroundColor Green
Write-Host "  PAYPAL_MODE           = $mode"
Write-Host "  PAYPAL_CLIENT_ID      = $(Get-MaskedPreview $clientId)"
Write-Host "  PAYPAL_CLIENT_SECRET  = $(Get-MaskedPreview $clientSecret)"
Write-Host "  PAYPAL_WEBHOOK_ID     = $(Get-MaskedPreview $webhookId)"
Write-Host "  ADMIN_USERNAME        = $adminUser"
Write-Host "  ADMIN_PASSWORD_HASH   = $(Get-MaskedPreview $adminPasswordHash)"
Write-Host "  SESSION_SECRET        = $(Get-MaskedPreview $sessionSecret)"
Write-Host "  BASE_URL              = $baseUrl"
Write-Host "  PORT                  = $port"
Write-Host ''

if (-not (Test-Path (Join-Path $ProjectPath 'node_modules'))) {
    Write-Host 'node_modules not found - run this first:' -ForegroundColor Yellow
    Write-Host '  npm install' -ForegroundColor Yellow
    Write-Host ''
}

Write-Host 'Start the server with:' -ForegroundColor Cyan
Write-Host '  npm start'
Write-Host ''
Write-Host "Homepage:     $baseUrl"
Write-Host "Admin login:  $baseUrl/admin/login"
if ($mode -eq 'sandbox') {
    Write-Host ''
    Write-Host 'Still testing locally? PayPal needs a public URL to send the webhook to -' -ForegroundColor DarkGray
    Write-Host 'run "ngrok http $port" and update the webhook URL in the PayPal dashboard' -ForegroundColor DarkGray
    Write-Host '(and PAYPAL_WEBHOOK_ID here) whenever that ngrok URL changes.' -ForegroundColor DarkGray
}
Write-Host ''
