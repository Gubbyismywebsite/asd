// Usage: npm run hash-password -- "your-chosen-password"
// Or set ADMIN_PASSWORD_PLAIN in the environment and call with no argument
// (used by setup.ps1, so the plaintext password never appears as a
// command-line argument).
const bcrypt = require('bcryptjs');

const password = process.argv[2] || process.env.ADMIN_PASSWORD_PLAIN;
if (!password) {
  console.error('Usage: npm run hash-password -- "your-chosen-password"');
  console.error('(or set ADMIN_PASSWORD_PLAIN in the environment)');
  process.exit(1);
}

bcrypt.hash(password, 12).then((hash) => {
  console.log('\nAdd this line to your .env file:\n');
  console.log(`ADMIN_PASSWORD_HASH=${hash}\n`);
});
