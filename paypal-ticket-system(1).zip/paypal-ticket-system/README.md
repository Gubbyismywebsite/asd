# PayPal Ticket System

A small, self-contained service-vendor website: customers pick a service, pay
with PayPal, and get a ticket number. Payment confirmation runs through
PayPal's Orders v2 API and a **signature-verified webhook** — a ticket is
only ever created after PayPal itself confirms the capture, not just because
the browser says checkout finished.

## How it works

1. Customer picks a service and clicks "Pay with PayPal" (homepage).
2. The browser's PayPal Buttons SDK calls your server to **create** a PayPal
   order (`POST /api/orders`), then, once the buyer approves it in the
   PayPal popup, calls your server to **capture** it
   (`POST /api/orders/:orderId/capture`).
3. PayPal sends your server a `PAYMENT.CAPTURE.COMPLETED` webhook. The server
   verifies the webhook's signature with PayPal's
   `verify-webhook-signature` API. Only once that verification succeeds does
   it generate a ticket (`TKT-XXXXXX`) and save it to the database.
4. The success page polls the server until that ticket exists, then shows
   the ticket number and a link to `/ticket/TKT-XXXXXX`.
5. You manage tickets (status, notes) from `/admin`.

This means the capture endpoint and the webhook are deliberately separate:
even if someone forged a request straight to the capture endpoint, no ticket
gets created without a PayPal-signed webhook event to back it up.

## Tech stack

- **Backend:** Node.js + Express
- **Database:** SQLite via `better-sqlite3` (single file, no server to run)
- **Frontend:** plain HTML + Tailwind CSS (CDN)
- **Payments:** `@paypal/checkout-server-sdk` (Orders v2) + PayPal's REST
  webhook-verification endpoint
- **Admin auth:** server-side session + bcrypt-hashed password

## Project layout

```
paypal-ticket-system/
├── server.js                  # App entry point, wiring, sessions, routes
├── src/
│   ├── db.js                  # SQLite schema + connection
│   ├── paypal.js              # Orders v2 client, OAuth token, webhook verification
│   ├── config/services.js     # The services you sell — edit this
│   ├── middleware/auth.js     # Admin session guard
│   ├── routes/
│   │   ├── orders.js          # POST /api/orders, POST /api/orders/:id/capture
│   │   ├── webhook.js         # POST /webhook/paypal  (ticket creation happens here)
│   │   ├── tickets.js         # GET /api/tickets/:ticketId (public lookup)
│   │   └── admin.js           # Admin login/logout + ticket list/update
│   └── utils/ticketId.js      # TKT-XXXXXX generator
├── public/
│   ├── index.html             # Homepage — service picker + PayPal buttons
│   ├── success.html           # Polls for the ticket after capture
│   ├── ticket.html            # Public ticket status page
│   └── admin/
│       ├── login.html
│       └── dashboard.html     # Ticket list, inline status/notes editing
├── scripts/hash-password.js   # Generates a bcrypt hash for ADMIN_PASSWORD_HASH
├── setup.ps1                  # Windows/PowerShell wizard that writes .env for you
├── data/                      # SQLite database file lives here (gitignored)
├── .env.example
└── package.json
```

## 1. Install

Requires **Node.js 18+** (for native `fetch`).

```bash
cd paypal-ticket-system
npm install
```

## 2. Set up your `.env`

**Windows / PowerShell:** skip the manual steps below and just run the
included wizard from the project folder:

```powershell
.\setup.ps1
```

It tells you what to go grab (see step 3 below), prompts for it, generates
your session secret and admin password hash for you, and writes `.env`.
It's safe to re-run later — existing values become the defaults, so
pressing Enter keeps them, and your previous `.env` is backed up first.

**Everyone else (macOS/Linux, or doing it by hand):**

```bash
cp .env.example .env
```

You'll fill in `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `PAYPAL_WEBHOOK_ID`,
`ADMIN_PASSWORD_HASH`, and `SESSION_SECRET` in the next steps.

Generate a session secret:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Generate your admin password hash:

```bash
npm run hash-password -- "choose-a-strong-password"
# paste the printed ADMIN_PASSWORD_HASH line into .env
```

## 3. Create a PayPal app (Sandbox first)

1. Go to <https://developer.paypal.com/dashboard/> and log in with your
   PayPal account (a regular PayPal account works — it gives you a
   Developer Dashboard).
2. **Apps & Credentials** → make sure you're on the **Sandbox** tab → **Create App**.
3. Name it anything (e.g. "Ticket System Sandbox"), choose **Merchant**,
   create it.
4. Copy the **Client ID** and **Secret** into `.env`:
   ```
   PAYPAL_MODE=sandbox
   PAYPAL_CLIENT_ID=...
   PAYPAL_CLIENT_SECRET=...
   ```
5. Under **Sandbox Accounts** (left nav), note the test *personal* (buyer)
   and *business* (merchant) accounts PayPal generates for you — you'll log
   in as the buyer account during testing.

## 4. Set up the webhook

PayPal needs to reach your server over the public internet, so for local
development you need a tunnel (e.g. [ngrok](https://ngrok.com)):

```bash
ngrok http 3000
```

Take the `https://xxxx.ngrok-free.app` URL it gives you, then:

1. In the same PayPal app (Sandbox tab) → **Webhooks** → **Add Webhook**.
2. Webhook URL: `https://xxxx.ngrok-free.app/webhook/paypal`
3. Event types: select at least **`PAYMENT.CAPTURE.COMPLETED`** (that's the
   only one this app listens for; you can subscribe to others too — unhandled
   events are safely acknowledged and ignored).
4. Save, then open the new webhook and copy its **Webhook ID** into `.env`:
   ```
   PAYPAL_WEBHOOK_ID=...
   ```

## 5. Run it

```bash
npm start
```

Visit `http://localhost:3000`, pick a service, and pay with your PayPal
**sandbox buyer** account's email/password (not your real PayPal login).
After approving payment you'll land on `/success`, which polls until the
webhook has created your ticket, then shows `TKT-XXXXXX` and a link to its
status page.

Log in at `/admin/login` with `ADMIN_USERNAME` and the password you hashed
in step 2 to see and update tickets.

### If the ticket never shows up

- Check your server logs — a failed signature check or a missing header logs
  a warning with the webhook event id.
- In the PayPal Developer Dashboard, open the webhook and check
  **Recent Deliveries** — PayPal shows you the HTTP status your server
  returned and lets you resend a delivery.
- Common causes: `PAYPAL_WEBHOOK_ID` doesn't match the webhook you created
  for this app, the ngrok tunnel restarted (new URL, old webhook still points
  at the dead one), or `PAYMENT.CAPTURE.COMPLETED` isn't in the webhook's
  subscribed events.

## 6. Switching from Sandbox to Live

1. In the PayPal Developer Dashboard, switch to the **Live** tab and create
   a **Live** app the same way (or use an existing one). Copy its live
   Client ID/Secret.
2. Add a **Live** webhook subscription pointing at your real domain:
   `https://yourdomain.com/webhook/paypal`, same event type. Copy its
   webhook ID.
3. Update `.env` on your production server:
   ```
   PAYPAL_MODE=live
   PAYPAL_CLIENT_ID=<live client id>
   PAYPAL_CLIENT_SECRET=<live secret>
   PAYPAL_WEBHOOK_ID=<live webhook id>
   NODE_ENV=production
   ```
4. Make sure production is served over **HTTPS** — PayPal requires it for
   live webhooks, and the session cookie is marked `secure` whenever
   `NODE_ENV=production`, so it won't be sent over plain HTTP.
5. Restart the app.

Sandbox and live credentials are completely separate; nothing else in the
code needs to change.

## Customizing what you sell

Edit `src/config/services.js` — each entry needs a unique `key`, a `name`,
`description`, `price` (decimal string), and `currency` (ISO code). The
homepage and checkout pick these up automatically.

## Database

SQLite file at `./data/tickets.db` (path configurable via `DATABASE_PATH`).

**`tickets`** — the table that matters: `ticket_id`, `paypal_order_id`,
`paypal_capture_id`, `amount`, `currency`, `customer_email`, `service_name`,
`status` (`paid` / `in_progress` / `completed`), `notes`, `created_at`,
`updated_at`.

**`pending_orders`** — created when an order is created, before payment;
supplies the service/email details the webhook attaches to the ticket.

**`processed_webhook_events`** — dedupes PayPal's webhook retries so the
same event never creates a ticket twice.

## Deploying

- Run it behind a process manager (`pm2 start server.js`, or a systemd unit)
  so it restarts on crash/reboot.
- Put it behind a reverse proxy that terminates TLS (nginx, Caddy, or your
  platform's load balancer) — `app.set('trust proxy', 1)` is already set so
  secure cookies and `req.ip` behave correctly behind one.
- Back up `data/tickets.db` — it's a single file, so a periodic copy is
  enough for a small deployment.
- Everything secret lives in `.env`, which is gitignored — never commit it.

## Security notes

- **Webhook signature verification is mandatory and always on** — see
  `src/paypal.js` → `verifyWebhookSignature` and `src/routes/webhook.js`.
  Any webhook delivery that fails verification (or is simply a forged POST
  with no valid PayPal signature headers) is rejected before anything is
  written to the database.
- Ticket creation only happens from the verified webhook handler — the
  capture endpoint (`/api/orders/:orderId/capture`) never creates a ticket
  itself, so the ticket table can't be written to without a PayPal-signed
  event.
- Admin password is stored as a bcrypt hash (`ADMIN_PASSWORD_HASH`), never
  in plaintext; admin routes are session-gated.
- Webhook events are deduped by PayPal's event `id`, so retried deliveries
  can't double-create a ticket.
- The public ticket-lookup endpoint only returns customer-facing fields —
  no PayPal order/capture IDs, no internal notes.
