require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');

const ordersRouter = require('./src/routes/orders');
const webhookRouter = require('./src/routes/webhook');
const ticketsRouter = require('./src/routes/tickets');
const adminRouter = require('./src/routes/admin');
const { requireAdmin } = require('./src/middleware/auth');
const services = require('./src/config/services');

const REQUIRED_ENV = ['PAYPAL_CLIENT_ID', 'PAYPAL_CLIENT_SECRET', 'PAYPAL_WEBHOOK_ID', 'SESSION_SECRET'];
const missing = REQUIRED_ENV.filter((k) => !process.env[k]);
if (missing.length) {
  console.warn(
    `Warning: missing environment variables: ${missing.join(', ')}. ` +
      'Copy .env.example to .env and fill these in before accepting real payments.'
  );
}

const app = express();
app.set('trust proxy', 1);

// The webhook route needs the parsed JSON body (matched by event id against
// PayPal's own copy during signature verification), so it gets mounted here,
// before the general body parser below, with its own express.json(). It
// never falls through to later middleware because every handler in
// webhookRouter ends the response itself.
app.use('/webhook', express.json({ limit: '1mb' }), webhookRouter);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'change-me-in-.env',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 1000 * 60 * 60 * 8 // 8 hours
    }
  })
);

app.use(express.static(path.join(__dirname, 'public')));

// --- Public config / API -------------------------------------------------
app.get('/api/config', (req, res) => {
  // Only the public client id ever reaches the browser — never the secret.
  res.json({ clientId: process.env.PAYPAL_CLIENT_ID || null, mode: process.env.PAYPAL_MODE || 'sandbox' });
});
app.get('/api/services', (req, res) => res.json(services));
app.use('/api/orders', ordersRouter);
app.use('/api/tickets', ticketsRouter);
app.use('/api/admin', adminRouter);

// --- Pages -----------------------------------------------------------------
app.get('/ticket/:ticketId', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'ticket.html'));
});

app.get('/admin/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin', 'login.html'));
});

app.get('/admin', requireAdmin, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin', 'dashboard.html'));
});

app.get('/success', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'success.html'));
});

app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT} (PayPal mode: ${process.env.PAYPAL_MODE || 'sandbox'})`);
});
