const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DB_PATH = process.env.DATABASE_PATH
  ? path.resolve(process.cwd(), process.env.DATABASE_PATH)
  : path.join(__dirname, '..', 'data', 'tickets.db');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  -- Created as soon as a PayPal order is created (before payment),
  -- so the webhook handler has the service/email details to attach to the ticket.
  CREATE TABLE IF NOT EXISTS pending_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    paypal_order_id TEXT UNIQUE NOT NULL,
    service_key TEXT NOT NULL,
    service_name TEXT NOT NULL,
    amount TEXT NOT NULL,
    currency TEXT NOT NULL,
    customer_email TEXT,
    status TEXT NOT NULL DEFAULT 'created',
    created_at TEXT NOT NULL
  );

  -- Only ever written by the verified webhook handler.
  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id TEXT UNIQUE NOT NULL,
    paypal_order_id TEXT UNIQUE NOT NULL,
    paypal_capture_id TEXT,
    amount TEXT NOT NULL,
    currency TEXT NOT NULL,
    customer_email TEXT,
    service_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'paid',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  -- Dedupes webhook deliveries so a PayPal retry never creates a second ticket.
  CREATE TABLE IF NOT EXISTS processed_webhook_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    webhook_event_id TEXT UNIQUE NOT NULL,
    event_type TEXT,
    received_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
`);

module.exports = db;
