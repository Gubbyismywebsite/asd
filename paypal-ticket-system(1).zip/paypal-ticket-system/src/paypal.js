const checkoutNodeJssdk = require('@paypal/checkout-server-sdk');

function isLive() {
  return (process.env.PAYPAL_MODE || 'sandbox').toLowerCase() === 'live';
}

function environment() {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    throw new Error('Missing PAYPAL_CLIENT_ID or PAYPAL_CLIENT_SECRET in environment variables.');
  }

  return isLive()
    ? new checkoutNodeJssdk.core.LiveEnvironment(clientId, clientSecret)
    : new checkoutNodeJssdk.core.SandboxEnvironment(clientId, clientSecret);
}

// Orders v2 client (create / capture), via the official SDK.
function client() {
  return new checkoutNodeJssdk.core.PayPalHttpClient(environment());
}

function apiBaseUrl() {
  return isLive() ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
}

// The checkout-server-sdk doesn't expose webhook-signature verification, so
// that one call is made directly against the REST API. It needs its own
// OAuth2 token (client_credentials grant) — separate from whatever the SDK
// does internally for order calls.
async function getAccessToken() {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
  const basicAuth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

  const res = await fetch(`${apiBaseUrl()}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basicAuth}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials'
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Failed to get PayPal access token: ${res.status} ${text}`);
  }

  const data = await res.json();
  return data.access_token;
}

/**
 * Verifies a PayPal webhook delivery using PayPal's own
 * /v1/notifications/verify-webhook-signature endpoint. This is mandatory:
 * it is the only thing stopping someone from POSTing a fake
 * PAYMENT.CAPTURE.COMPLETED event straight at your server.
 *
 * @param {Record<string,string>} headers - the incoming request's headers (lowercased keys)
 * @param {object} webhookEventBody - the parsed JSON body PayPal sent
 * @returns {Promise<boolean>}
 */
async function verifyWebhookSignature(headers, webhookEventBody) {
  const webhookId = process.env.PAYPAL_WEBHOOK_ID;
  if (!webhookId) {
    throw new Error('Missing PAYPAL_WEBHOOK_ID in environment variables.');
  }

  const required = [
    'paypal-auth-algo',
    'paypal-cert-url',
    'paypal-transmission-id',
    'paypal-transmission-sig',
    'paypal-transmission-time'
  ];
  for (const h of required) {
    if (!headers[h]) {
      throw new Error(`Missing required PayPal webhook header: ${h}`);
    }
  }

  const accessToken = await getAccessToken();

  const payload = {
    auth_algo: headers['paypal-auth-algo'],
    cert_url: headers['paypal-cert-url'],
    transmission_id: headers['paypal-transmission-id'],
    transmission_sig: headers['paypal-transmission-sig'],
    transmission_time: headers['paypal-transmission-time'],
    webhook_id: webhookId,
    webhook_event: webhookEventBody
  };

  const res = await fetch(`${apiBaseUrl()}/v1/notifications/verify-webhook-signature`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Webhook verification request failed: ${res.status} ${text}`);
  }

  const data = await res.json();
  return data.verification_status === 'SUCCESS';
}

module.exports = {
  client,
  checkoutNodeJssdk,
  verifyWebhookSignature,
  isLive
};
