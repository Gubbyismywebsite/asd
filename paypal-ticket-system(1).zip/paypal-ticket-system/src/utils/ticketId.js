const crypto = require('crypto');

// Excludes 0/O/1/I so printed/read-aloud ticket numbers are unambiguous.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function randomSegment(length = 6) {
  const bytes = crypto.randomBytes(length);
  let out = '';
  for (let i = 0; i < length; i++) {
    out += ALPHABET[bytes[i] % ALPHABET.length];
  }
  return out;
}

/**
 * Generates a unique TKT-XXXXXX id.
 * @param {(candidate: string) => any} existsFn - should return a truthy value if the id is taken.
 */
function generateTicketId(existsFn, attempts = 10) {
  for (let i = 0; i < attempts; i++) {
    const candidate = `TKT-${randomSegment(6)}`;
    if (!existsFn(candidate)) {
      return candidate;
    }
  }
  throw new Error('Could not generate a unique ticket ID after several attempts.');
}

module.exports = { generateTicketId };
