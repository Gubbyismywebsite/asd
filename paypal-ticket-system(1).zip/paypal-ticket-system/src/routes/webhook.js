const express = require('express');
const router = express.Router();
const db = require('../db');
const paypal = require('../paypal');
const { generateTicketId } = require('../utils/ticketId');

// This is the ONLY place tickets get created. Everything above this point
// (capture endpoint, client-side JS) is just "please take the payment" —
// nothing becomes a paid ticket until PayPal itself confirms it here, with
// a signature we've checked.
router.post('/paypal', async (req, res) => {
  const event = req.body;

  if (!event || !event.event_type) {
    return res.status(400).send('Malformed webhook payload.');
  }

  try {
    const isValid = await paypal.verifyWebhookSignature(req.headers, event);
    if (!isValid) {
      console.warn('Rejected webhook delivery: signature verification failed.', event.id);
      return res.status(400).send('Invalid webhook signature.');
    }
  } catch (err) {
    console.error('Error verifying webhook signature:', err);
    return res.status(400).send('Could not verify webhook signature.');
  }

  // Idempotency: PayPal retries deliveries, so the same event id can arrive
  // more than once. Make sure it's only ever acted on once.
  const already = db
    .prepare('SELECT 1 FROM processed_webhook_events WHERE webhook_event_id = ?')
    .get(event.id);
  if (already) {
    return res.status(200).send('Already processed.');
  }

  db.prepare(
    'INSERT INTO processed_webhook_events (webhook_event_id, event_type, received_at) VALUES (?, ?, ?)'
  ).run(event.id, event.event_type, new Date().toISOString());

  if (event.event_type === 'PAYMENT.CAPTURE.COMPLETED') {
    try {
      createTicketFromCapture(event);
    } catch (err) {
      // Still ack with 200 so PayPal doesn't hammer this endpoint with
      // retries over a bug on our end — the event id above is logged either
      // way, so nothing is silently lost.
      console.error('Error creating ticket from webhook event:', event.id, err);
    }
  }

  res.status(200).send('OK');
});

function createTicketFromCapture(event) {
  const resource = event.resource || {};
  const orderId = resource.supplementary_data?.related_ids?.order_id;
  const captureId = resource.id;
  const amount = resource.amount?.value;
  const currency = resource.amount?.currency_code;

  if (!orderId) {
    console.warn('Webhook event missing an order id; skipping ticket creation.', event.id);
    return;
  }

  const existingTicket = db.prepare('SELECT 1 FROM tickets WHERE paypal_order_id = ?').get(orderId);
  if (existingTicket) {
    return; // Already handled — e.g. a duplicate capture-completed event.
  }

  const pending = db.prepare('SELECT * FROM pending_orders WHERE paypal_order_id = ?').get(orderId);

  const serviceName = pending ? pending.service_name : resource.custom_id || 'Service';
  const customerEmail = pending?.customer_email || resource.payer?.email_address || null;

  const ticketId = generateTicketId((candidate) =>
    db.prepare('SELECT 1 FROM tickets WHERE ticket_id = ?').get(candidate)
  );

  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO tickets
       (ticket_id, paypal_order_id, paypal_capture_id, amount, currency, customer_email, service_name, status, notes, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'paid', '', ?, ?)`
  ).run(
    ticketId,
    orderId,
    captureId || null,
    amount || pending?.amount || '0.00',
    currency || pending?.currency || 'USD',
    customerEmail,
    serviceName,
    now,
    now
  );

  if (pending) {
    db.prepare(`UPDATE pending_orders SET status = 'completed' WHERE paypal_order_id = ?`).run(orderId);
  }

  console.log(`Ticket ${ticketId} created for PayPal order ${orderId}.`);
}

module.exports = router;
