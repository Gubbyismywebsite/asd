const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

router.post('/login', async (req, res) => {
  const { username, password } = req.body || {};

  const hash = process.env.ADMIN_PASSWORD_HASH || '';
  const validUsername = Boolean(username) && username === process.env.ADMIN_USERNAME;
  const validPassword = hash ? await bcrypt.compare(password || '', hash) : false;

  if (!validUsername || !validPassword) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  req.session.isAdmin = true;
  res.json({ ok: true });
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

router.get('/tickets', requireAdmin, (req, res) => {
  const tickets = db.prepare('SELECT * FROM tickets ORDER BY created_at DESC').all();
  res.json(tickets);
});

router.patch('/tickets/:ticketId', requireAdmin, (req, res) => {
  const { status, notes } = req.body || {};
  const allowedStatuses = ['paid', 'in_progress', 'completed'];

  const ticket = db.prepare('SELECT * FROM tickets WHERE ticket_id = ?').get(req.params.ticketId);
  if (!ticket) {
    return res.status(404).json({ error: 'Ticket not found.' });
  }

  const newStatus = status && allowedStatuses.includes(status) ? status : ticket.status;
  const newNotes = typeof notes === 'string' ? notes : ticket.notes;

  db.prepare('UPDATE tickets SET status = ?, notes = ?, updated_at = ? WHERE ticket_id = ?').run(
    newStatus,
    newNotes,
    new Date().toISOString(),
    req.params.ticketId
  );

  res.json({ ok: true });
});

module.exports = router;
