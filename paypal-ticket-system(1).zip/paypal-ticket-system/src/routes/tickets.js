const express = require('express');
const router = express.Router();
const db = require('../db');

// Public lookup used by the /ticket/:ticketId page. Intentionally returns
// only customer-facing fields — no PayPal order/capture ids, no internal notes.
router.get('/:ticketId', (req, res) => {
  const ticket = db
    .prepare(
      `SELECT ticket_id, service_name, status, amount, currency, created_at, updated_at
       FROM tickets WHERE ticket_id = ?`
    )
    .get(req.params.ticketId);

  if (!ticket) {
    return res.status(404).json({ error: 'Ticket not found.' });
  }

  res.json(ticket);
});

module.exports = router;
