const express = require('express');
const router = express.Router();
const db = require('../db');
const paypal = require('../paypal');
const services = require('../config/services');

function findService(key) {
  return services.find((s) => s.key === key);
}

// Creates a PayPal order for a chosen service. Called by the PayPal
// Buttons' createOrder callback on the homepage.
router.post('/', async (req, res) => {
  try {
    const { serviceKey, customerEmail } = req.body || {};
    const service = findService(serviceKey);
    if (!service) {
      return res.status(400).json({ error: 'Unknown service selected.' });
    }

    const request = new paypal.checkoutNodeJssdk.orders.OrdersCreateRequest();
    request.prefer('return=representation');
    request.requestBody({
      intent: 'CAPTURE',
      purchase_units: [
        {
          custom_id: service.key,
          description: service.name,
          amount: {
            currency_code: service.currency,
            value: service.price
          }
        }
      ],
      application_context: {
        brand_name: process.env.BRAND_NAME || 'Service Vendor',
        shipping_preference: 'NO_SHIPPING',
        user_action: 'PAY_NOW'
      }
    });

    const order = await paypal.client().execute(request);

    db.prepare(
      `INSERT INTO pending_orders
         (paypal_order_id, service_key, service_name, amount, currency, customer_email, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'created', ?)`
    ).run(
      order.result.id,
      service.key,
      service.name,
      service.price,
      service.currency,
      customerEmail || null,
      new Date().toISOString()
    );

    res.json({ id: order.result.id });
  } catch (err) {
    console.error('Error creating PayPal order:', err);
    res.status(500).json({ error: 'Could not create PayPal order.' });
  }
});

// Captures an approved order. This only tells PayPal to take the payment —
// the ticket itself is created by the verified webhook handler (see
// src/routes/webhook.js), not here, so a forged call to this endpoint alone
// can never create a ticket.
router.post('/:orderId/capture', async (req, res) => {
  try {
    const { orderId } = req.params;

    const pending = db.prepare('SELECT 1 FROM pending_orders WHERE paypal_order_id = ?').get(orderId);
    if (!pending) {
      return res.status(404).json({ error: 'Order not found.' });
    }

    const request = new paypal.checkoutNodeJssdk.orders.OrdersCaptureRequest(orderId);
    request.requestBody({});

    const capture = await paypal.client().execute(request);

    db.prepare(`UPDATE pending_orders SET status = 'capture_requested' WHERE paypal_order_id = ?`).run(orderId);

    res.json({ status: capture.result.status, orderId });
  } catch (err) {
    console.error('Error capturing PayPal order:', err);
    res.status(500).json({ error: 'Could not capture PayPal order.' });
  }
});

// Polled by the success page while it waits for the webhook to land and
// create the ticket.
router.get('/:orderId/ticket', (req, res) => {
  const ticket = db
    .prepare('SELECT ticket_id, status FROM tickets WHERE paypal_order_id = ?')
    .get(req.params.orderId);

  if (!ticket) {
    return res.json({ ready: false });
  }
  res.json({ ready: true, ticketId: ticket.ticket_id, status: ticket.status });
});

module.exports = router;
