// Edit this list to match what you actually sell. `key` must be unique and
// is never shown to the customer; `price` is a plain decimal string in the
// smallest "whole unit" PayPal expects for that currency (e.g. "49.00" USD).
module.exports = [
  {
    key: 'standard',
    name: 'Standard Service',
    description: 'Our core service package, delivered within 3-5 business days.',
    price: '49.00',
    currency: 'USD'
  },
  {
    key: 'priority',
    name: 'Priority Service',
    description: 'Expedited turnaround within 24-48 hours.',
    price: '99.00',
    currency: 'USD'
  },
  {
    key: 'consultation',
    name: '1-on-1 Consultation',
    description: 'A 45-minute consultation call with a specialist.',
    price: '149.00',
    currency: 'USD'
  }
];
